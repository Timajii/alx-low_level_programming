This is a script to help push code to github.
with just one line command and specifying the commit message
*****HOW TO USE ******
after forking or cloning allow permissions for all users by typing "chmod a+x git_push"
then move to /bin directory using sudo mv git_push ./bin/
you can call the script from anywhere on your cli
