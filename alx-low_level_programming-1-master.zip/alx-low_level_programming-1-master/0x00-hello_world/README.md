This is a project on basic c programming 
