A folder on c program debugging
