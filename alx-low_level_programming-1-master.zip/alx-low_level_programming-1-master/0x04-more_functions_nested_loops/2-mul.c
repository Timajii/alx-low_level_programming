#include "main.h"
/**
 * mul - Multiplies two integers
 * @a: user input one
 * @b: user input two
 * Return: product of the multiplication
 */
int mul(int a, int b)
{
	int outcome;

	outcome = a * b;

	return (outcome);
}
