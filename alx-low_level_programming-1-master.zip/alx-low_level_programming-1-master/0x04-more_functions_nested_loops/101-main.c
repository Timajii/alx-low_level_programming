#include "main.h"
/**
 * main - entry point
 * Return: 0
 */
int main(void)
{
	print_number(98);
	_putchar('\n');
	print_number(402);
	print_number(1024);
	print_number(0);
	print_number(-98);
	return(0);
}
