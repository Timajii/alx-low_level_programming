A Folder of different uses cases of the if, else, while and for loop of the c program
