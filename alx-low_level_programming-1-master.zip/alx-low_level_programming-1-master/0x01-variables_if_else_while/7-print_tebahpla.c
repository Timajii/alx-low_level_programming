#include <stdio.h>
/**
 * main - Entry point
 * Return: Always 0 (Success)
 */
int main(void)
{
	int ahpla;

	for (ahpla = 'z'; ahpla >= 'a'; ahpla--)
		putchar(ahpla);
	putchar('\n');
	return (0);
}
