Readme of the f program nested loops and functions
