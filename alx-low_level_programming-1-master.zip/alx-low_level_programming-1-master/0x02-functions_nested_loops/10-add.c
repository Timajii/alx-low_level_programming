#include "main.h"
/**
 * add - Adds two integers and prints the result
 *@a: user first input
 *@b: user second input
 * Return: Returns the value of addition
 *
 */
int add(int a, int b)
{
	int addition;

	addition = a + b;
	return (addition);
}
